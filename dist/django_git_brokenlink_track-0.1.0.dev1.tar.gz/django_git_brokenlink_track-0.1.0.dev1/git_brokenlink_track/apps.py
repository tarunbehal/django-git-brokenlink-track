from __future__ import unicode_literals

from django.apps import AppConfig


class GitTrackIssueConfig(AppConfig):
    name = 'git_track_issue'
